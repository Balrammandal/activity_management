<nav class="navbar-default navbar-side" role="navigation">
    <div id="sideNav" href=""><i class="fa fa-caret-right"></i></div>
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">

            <li>
                <a class="active-menu" href="{{route('user_dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a>
            </li>
        </ul>

    </div>

</nav>
<!-- /. NAV SIDE  -->