<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="header">
        <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li class="active">Activities</li>
        </ol>
    </div>
    <div id="page-inner">
        <!-- /. ROW  -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                       <?php echo e($customer_details['name']); ?> Activity List <a href="<?php echo e(route('add_activities',$customer_id)); ?>" class="btn btn-primary">Add Activity</a>
                    </div>
                    <div class="panel-body">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div><?php echo e($error); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>S No.</th>
                                    <th>Activity Type</th>
                                    <th>Time</th>
                                    <th>Description</th>
                                    <th>Next Activity Description</th>
                                    <th>Next Activity Time</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1;?>
                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($row->activity_type); ?></td>
                                    <td><?php echo e($row->time); ?></td>
                                    <td><?php echo e($row->description); ?></td>
                                    <td><?php echo e($row->next_act_desc); ?></td>
                                    <td><?php echo e($row->next_act_time); ?></td>
                                </tr>
                                    <?php $i++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>